import React from 'react';

const Contact = () => {
    return (
        <div>
            <h1>Contact Us</h1>
            <p>For any inquiries, please contact us at: <a href="mailto:info@templesdiary.com">info@templesdiary.com</a></p>
        </div>
    );
};

export default Contact;
