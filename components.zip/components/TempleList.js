import React, { useEffect, useState } from 'react';
import axios from 'axios';

const TempleList = () => {
    const [temples, setTemples] = useState([]);

    useEffect(() => {
        axios.get('/api/temples')
            .then(response => setTemples(response.data))
            .catch(error => console.error('There was an error fetching the temples!', error));
    }, []);

    return (
        <div>
            <h1>Temple List1</h1>
            <ul>
                {temples.map(temple => (
                    <li key={temple.name}>
                        "Deity Name" - {temple.deity} <br></br>
                        "Location" - {temple.location}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default TempleList;
