import React from 'react';

const About = () => {
    return (
        <div>
            <h1>About Us</h1>
            <p>We provide comprehensive information about temples in Andhra Pradesh and Telangana, including the deities worshipped, historical significance, rituals, and events.</p>
        </div>
    );
};

export default About;
