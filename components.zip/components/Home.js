import React from 'react';

const Home = () => {
    return (
        <div className="App">
          <header className="header">
            <h1>Temple Dairy</h1>
            <p>Your Guide to Hindu Temples Across India</p>
          </header>
          <nav className="nav">
            <a href="#temple-directory">Temples</a>
            <a href="#darshan-booking">Book Darshan</a>
            <a href="#prasadam-store">Prasadam</a>
            <a href="#donations">Donations</a>
            <a href="#special-poojas">Special Poojas</a>
          </nav>
          <main className="main-section">
            <h2>Welcome to the Temple Dairy Website</h2>
            <p>Explore the rich cultural heritage and spirituality of Hindu temples across India.</p>
            <div className="image-gallery">
              <img src="https://i.pinimg.com/236x/12/d3/74/12d374e6ffb8759112f3681894bba601.jpg" alt="Lord Shiva" />
              <img src="https://i.pinimg.com/236x/68/86/64/688664976979a3690697693b06646ed2.jpg" alt="Lord Vishnu" />
              <img src="https://i.pinimg.com/736x/36/f4/a2/36f4a26c4757dc30b01cf67e56dc5f5a.jpg" alt="Lord Ganesha" />
              <img src="https://i.pinimg.com/564x/57/c7/9e/57c79e2af07608dd53ce19d73dee6559.jpg" alt="Goddess Lakshmi" />
            </div>
          </main>
          <section className="section" id="temple-directory">
            <h3>Discover Temples</h3>
            <p>Search and find detailed information about various temples, including their history, significance, and more.</p>
          </section>
          <section className="section" id="darshan-booking">
            <h3>Book Your Darshan</h3>
            <p>Plan your visit and book darshan tickets easily through our platform.</p>
          </section>
          <section className="section" id="prasadam-store">
            <h3>Buy Prasadam</h3>
            <p>Order prasadam and other temple-related items online.</p>
          </section>
          <section className="section" id="donations">
            <h3>Make a Donation</h3>
            <p>Contribute to the upkeep and maintenance of the temples.</p>
          </section>
          <section className="section" id="special-poojas">
            <h3>Special Poojas</h3>
            <p>Book special poojas and rituals performed at the temples.</p>
          </section>
          <footer className="footer">
            <p>&copy; 2024 Temple Directory. All rights reserved.</p>
          </footer>
        </div>
      );
    }

export default Home;
