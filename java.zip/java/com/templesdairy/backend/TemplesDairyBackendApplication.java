package com.templesdairy.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TemplesDairyBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TemplesDairyBackendApplication.class, args);
	}

	
}
