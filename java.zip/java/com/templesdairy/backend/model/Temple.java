package com.templesdairy.backend.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "temples")
public class Temple {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long temple_id;
	private String name;
    private String deity;
    private String location;
    private String history;
    private String mythological_relations;
    private String best_times_to_visit;
    private String dos_and_donts;
    private String dress_code;
    private String accomodation_details;
    private String management_committee;
    private String priest_details;
    
    public Long getTemple_id() {
		return temple_id;
	}

	public void setTemple_id(Long temple_id) {
		this.temple_id = temple_id;
	}

	public String getMythological_relations() {
		return mythological_relations;
	}

	public void setMythological_relations(String mythological_relations) {
		this.mythological_relations = mythological_relations;
	}

	public String getBest_times_to_visit() {
		return best_times_to_visit;
	}

	public void setBest_times_to_visit(String best_times_to_visit) {
		this.best_times_to_visit = best_times_to_visit;
	}

	public String getDos_and_donts() {
		return dos_and_donts;
	}

	public void setDos_and_donts(String dos_and_donts) {
		this.dos_and_donts = dos_and_donts;
	}

	public String getDress_code() {
		return dress_code;
	}

	public void setDress_code(String dress_code) {
		this.dress_code = dress_code;
	}

	public String getAccomodation_details() {
		return accomodation_details;
	}

	public void setAccomodation_details(String accomodation_details) {
		this.accomodation_details = accomodation_details;
	}

	public String getManagement_committee() {
		return management_committee;
	}

	public void setManagement_committee(String management_committee) {
		this.management_committee = management_committee;
	}

	public String getPriest_details() {
		return priest_details;
	}

	public void setPriest_details(String priest_details) {
		this.priest_details = priest_details;
	}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDeity() {
        return deity;
    }

    public void setDeity(String deity) {
        this.deity = deity;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getHistory() {
        return history;
    }

    public void setHistory(String history) {
        this.history = history;
    }

}
