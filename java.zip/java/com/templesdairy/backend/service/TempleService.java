package com.templesdairy.backend.service;

import com.templesdairy.backend.model.Temple;
import com.templesdairy.backend.repository.TempleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class TempleService {

    @Autowired
    private TempleRepository templeRepository;

    public List<Temple> getAllTemples() {
        return templeRepository.findAll();
    }
    
    public Optional<Temple> findTemplyById(Long id) {
    	return templeRepository.findById(id);
    }

//    public List<Temple> getAllTemples() {
//    	List<Temple> response = new ArrayList<Temple>();
//    	Temple temp1 = new Temple();
//    	temp1.setName("Sri Ganapathi Subramanya Malikapurathamma sametha Ayyappa Swamy vaari Devasthaanam");
//    	temp1.setDeity("Ayyappa Swamy");
//    	temp1.setLocation("Penumanchili");
//    	
//    	Temple temp2 = new Temple();
//    	temp2.setName("Shiridi Sai Aalayam");
//    	temp2.setDeity("Sai Baba");
//    	temp2.setLocation("Kothapeta");
//    	
//    	response.add(temp1);
//    	response.add(temp2);
//    	
//        return response;
//    }

    
    public Temple getTempleById(Long id) {
        return templeRepository.findById(id).orElse(null);
    }

    public Temple saveTemple(Temple temple) {
        return templeRepository.save(temple);
    }

    public void deleteTemple(Long id) {
        templeRepository.deleteById(id);
    }
}
