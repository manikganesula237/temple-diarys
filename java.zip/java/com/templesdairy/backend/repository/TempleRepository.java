package com.templesdairy.backend.repository;

import com.templesdairy.backend.model.Temple;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TempleRepository extends JpaRepository<Temple, Long> {
	
	
	
}
