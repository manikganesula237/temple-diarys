package com.templesdairy.backend.controller;

import com.templesdairy.backend.model.Temple;
import com.templesdairy.backend.service.TempleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/temples")
@CrossOrigin
public class TempleController {

    @Autowired
    private TempleService templeService;

//    @GetMapping
//    public List<Temple> getAllTemples() {
//        return templeService.getAllTemples();
//    }
    
    @GetMapping
    public List<Temple> getAllTemples() {
        return templeService.getAllTemples();
    }

    @GetMapping("/{id}")
    public Temple getTempleById(@PathVariable Long id) {
        return templeService.getTempleById(id);
    }

    @PostMapping
    public Temple createTemple(@RequestBody Temple temple) {
        return templeService.saveTemple(temple);
    }

    @PutMapping("/{id}")
    public Temple updateTemple(@PathVariable Long id, @RequestBody Temple temple) {
        temple.setTemple_id(id);
        return templeService.saveTemple(temple);
    }

    @DeleteMapping("/{id}")
    public void deleteTemple(@PathVariable Long id) {
        templeService.deleteTemple(id);
    }
}
